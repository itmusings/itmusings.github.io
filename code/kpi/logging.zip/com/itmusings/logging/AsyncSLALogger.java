/**
 * Copyright (c) itmusings  All rights reserved.
 */
package com.itmusings.logging;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.DisposableBean;

/**
 * Logs stuff asynchronously using other loggers. Uses jdk5 executor service
 * 
 * @author raja
 * 
 */
public class AsyncSLALogger implements DisposableBean, SLALogger {
	private ExecutorService executor;
	private boolean enabled = true;
	private SLALogger slaLogger;
	private boolean executorCreatedByMe = false;

	public AsyncSLALogger(SLALogger logger) {
		slaLogger = logger;
	}

	public ExecutorService getExecutor() {
		return (executor == null) ? makeExecutor() : executor;
	}

	public void destroy() {
		if (executorCreatedByMe) {
			executor.shutdown();
			executorCreatedByMe = false;
		}
	}

	/**
	 * Over-ride this method if a new executor is desired. Should suffice for
	 * most needs.
	 * 
	 * @return
	 */
	protected ExecutorService makeExecutor() {
		executorCreatedByMe = true;
		return executor = Executors.newSingleThreadExecutor();
	}

	public void setExecutor(ExecutorService executor) {
		this.executor = executor;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 * Submits the callable to the executor. This would execute the task
	 * asynchronously at some future time.
	 * 
	 * @param record
	 */
	public void sla(SLARecord record) {
		if (!enabled)
			return;
		getExecutor().submit(new RunnableAdapterLogger(record, slaLogger));
	}

	private static class RunnableAdapterLogger implements Runnable {
		private SLARecord slaRecord;
		private SLALogger slaLogger;

		public void run() {
			slaLogger.sla(slaRecord);
		}

		public RunnableAdapterLogger(SLARecord slaRecord, SLALogger slaWriter) {
			this.slaRecord = slaRecord;
			this.slaLogger = slaWriter;
		}

	}

}
