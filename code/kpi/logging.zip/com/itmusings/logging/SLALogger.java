/**
 * Copyright (c) itmusings All rights reserved.
 */
package com.itmusings.logging;

public interface SLALogger {
	public void sla(SLARecord slaRecord);
}
