/**
 * Copyright (c) itmusings   All rights reserved.
 */
package com.itmusings.logging;

import java.text.SimpleDateFormat;

import com.itmusing.utils.RandomGUID;

public class SLATime {
	/**
	 * What kind of SLA are we measuring?
	 */
	private String slatimeId;
	private String name;
	private long startTime;
	private long endTime;

	public SLATime(String name) {
		this.slatimeId = RandomGUID.getUID();
		this.name = name;
		this.startTime = System.currentTimeMillis();
	}

	public void addEndTime() {
		this.endTime = System.currentTimeMillis();
	}

	public long getTimeElapsed() {
		return (endTime - startTime) / 1000;
	}

	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final SLATime other = (SLATime) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public String toString() {
		SimpleDateFormat format = (SimpleDateFormat) SimpleDateFormat
				.getInstance();
		format.applyPattern("yyyy.MM.dd-HH:mm:ss");
		StringBuffer buf = new StringBuffer("<sla-time name='" + name + "'>");
		if (startTime != 0L) {
			buf.append("<start-time>" + format.format(startTime)
					+ "</start-time>");
		}
		if (endTime != 0L) {
			buf.append("<end-time>" + format.format(endTime) + "</end-time>");
		}
		buf.append("<time-elapsed>" + getTimeElapsed() + "</time-elapsed>");
		buf.append("</sla-time>");
		return buf.toString();
	}

	public long getStartTime() {
		return startTime;
	}

	public long getEndTime() {
		return this.endTime;
	}

	public String getSlatimeId() {
		return slatimeId;
	}

	public void setSlatimeId(String slatimeId) {
		this.slatimeId = slatimeId;
	}

}
