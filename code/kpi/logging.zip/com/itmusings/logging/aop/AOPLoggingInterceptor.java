/**
 * Copyright (c) itmusings All rights reserved.
 */
package com.itmusings.logging.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import com.itmusings.logging.SLALoggingInterceptor;
import com.itmusings.logging.SLARecord;

/**
 * Provides an AOP logging proxy around a method.
 * 
 * @author raja
 * 
 */
public abstract class AOPLoggingInterceptor extends SLALoggingInterceptor
		implements MethodInterceptor {

	public final Object invoke(MethodInvocation mi) throws Throwable {
		beforeCommand(mi);
		Object ret = mi.proceed();
		afterCommand(mi);
		return ret;
	}

	@Override
	protected SLARecord getSLARecord(Object context) {
		return getSLARecordFromMethodInvocation((MethodInvocation) context);
	}

	@Override
	protected void setSLARecord(Object context, SLARecord slaRecord) {
		setSLARecordInMethodInvocation((MethodInvocation) context, slaRecord);
	}

	protected abstract SLARecord getSLARecordFromMethodInvocation(
			MethodInvocation mi);

	protected abstract void setSLARecordInMethodInvocation(MethodInvocation mi,
			SLARecord slaRecord);
}
