/**
 * Copyright (c) itmusings All rights reserved.
 */
package com.itmusings.logging;

import java.util.HashMap;
import java.util.Map;

import com.itmusings.utils.RandomGUID;

public class SLARecord {
	/**
	 * A unique key to track this request end to end.
	 */
	private String requestId;
	/**
	 * The Originating SLA Type.
	 */
	private String originatingSlaType;
	private Map<String, SLATime> slatimes = new HashMap<String, SLATime>();

	public SLARecord() {
		// set the default request Id as a random number.
		requestId = RandomGUID.getUID();

	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Map<String, SLATime> getSlatimes() {
		return slatimes;
	}

	public void setSlatimes(Map<String, SLATime> slatimes) {
		this.slatimes = slatimes;
	}

	public void add(SLATime t) {
		slatimes.put(t.getName(), t);
	}

	public SLATime getSlaTime(String name) {
		return slatimes.get(name);
	}

	public String getSlatimeId(String name) {
		return (slatimes.get(name) == null) ? null : slatimes.get(name)
				.getSlatimeId();
	}

	public long getStartTime(String name) {
		return (slatimes.get(name) == null) ? 0L : slatimes.get(name)
				.getStartTime();
	}

	public long getEndTime(String name) {
		return (slatimes.get(name) == null) ? 0L : slatimes.get(name)
				.getEndTime();
	}

	public long getTimeElapsed(String name) {
		return (slatimes.get(name) == null) ? 0L : slatimes.get(name)
				.getTimeElapsed();
	}

	public void addStartTime(String name) {
		createOrAccessTime(name);
	}

	public void addEndTime(String name) {
		SLATime t = createOrAccessTime(name);
		t.addEndTime();
	}

	private SLATime createOrAccessTime(String name) {
		SLATime t = slatimes.get(name);
		if (t == null) {
			slatimes.put(name, t = new SLATime(name));
		}
		return t;
	}

	public String toString() {
		StringBuffer buf = new StringBuffer("<sla-record>");
		buf.append("<request-id>" + requestId + "</request-id>");
		buf.append("<sla-times>");
		for (SLATime t : slatimes.values()) {
			buf.append(t.toString());
		}
		buf.append("</sla-times>");
		buf.append("</sla-record>");
		return buf.toString();
	}

	public String getOriginatingSlaType() {
		return originatingSlaType;
	}

	public void setOriginatingSlaType(String nameOfOriginator) {
		this.originatingSlaType = nameOfOriginator;
	}
}
