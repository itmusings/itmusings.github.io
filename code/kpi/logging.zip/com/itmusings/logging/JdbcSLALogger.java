/**
 * Copyright (c) itmusings All rights reserved.
 */
package com.itmusings.logging;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.util.Assert;

import com.itmusings.concurrent.AsyncExecutor;

/**
 * Implements SLALogger using JDBC. Accommodates a flexible table design with
 * both single and multiple records.
 * <li> A single record table contains all the sla times for all sla types in
 * the same record - recommended as it is easy to query against.
 * <li> A multiple record table format contains all the details of one SLA type
 * in one record. There would be as many records as there are SLA times. - This
 * is recommended in situations where the number of SLA types are not known
 * upfront. This model presents difficulties in retrieving and hence would
 * require a view to accomplish that.
 * <p>
 * Layout of a single record table with two slaColumns - web and service.<br>
 * <code>
 * create table sla (
 * 	 requestId varchar(32) - unique primary key
 *  webStartTime timestamp
 *  webEndTime timestamp
 *  webTimeElapsed integer
 *  serviceStartTime timestamp
 *  serviceEndTime timestamp
 *  serviceTimeElapsed integer
 *  )
 *  </code>
 * <p>
 * Multiple record format<br>
 * <code>
 *  create table sla (
 *  slaId varchar(32) - unique primary key
 * 	 requestId varchar(32)  -- this can be duplicated for different sla types.
 *  slaType varchar(20) 
 *  startTime timestamp
 *  endTime timestamp
 *  timeElapsed integer
 *  )
 *  </code>
 * A view can be created to do retrieves for multiple records storage. A typical
 * view looks as follows: <code>
 *  create view VIEW_SLA as
 *    select requestId, 
 *    max(case when slaType = 'WEB' then startTime else null end)webStartTime,
 *    max(case when slaType = 'WEB' then endTime else null end) webEndTime,
 *    max(case when slaType = 'WEB' then timeElapsed else null end) webTimeElapsed,
 *    max(case when slaType = 'SERVICE' then startTime else null end) serviceStartTime,
 *    max(case when slaType = 'SERVICE' then endTime else null end) serviceEndTime,
 *    max(case when slaType = 'SERVICE' then timeElapsed else null end) serviceTimeElapsed,
 *     from
 *     sla 
 *     group by requestId
 *  </code>
 * 
 * <p>
 * This class typically should be executed asynchronously.
 * 
 * @see AsyncExecutor
 * 
 * @author raja
 * 
 */
public class JdbcSLALogger implements SLALogger, InitializingBean {
	private static final Log logger = LogFactory.getLog(JdbcSLALogger.class);
	/**
	 * The table that stores the sla information.
	 */
	private String tableName = "sla";
	/**
	 * List of columns in the table. only applicable for single record table.
	 * For multiple record updates, each record would be written into the
	 * database table. Hence there would be no need for this field to be set.
	 */
	private String[] slaColumns;

	protected DataSource datasource;
	/**
	 * Is startTime stored in db? By default it is assumed to be stored but can
	 * change from one implementation to another.
	 */
	protected boolean startTimeStored = true;
	/**
	 * Is endTime stored in db? By default yes.
	 */
	protected boolean endTimeStored = true;
	/**
	 * Is time elapsed stored? default is true. Recommended to store this since
	 * time elapsed is the most queried attribute.
	 */
	protected boolean timeElapsedStored = true;
	/**
	 * Is sla type stored? By default false.
	 */
	protected boolean slaTypeStored = false;
	/**
	 * Gives the ability to store the SLA transactions as multiple records.
	 * Useful if it is hard to predict how many sla times would be committed
	 * upfront (because the processing follows various alternate routes which
	 * have different number of SLA logging points)
	 * <p>
	 * We prefer single records for the sake of simplicity in inserting as well
	 * as retrieving SLA information. But if the # logging points is highly
	 * variable (as often happens in a system with a complex orchestration
	 * process) it is simpler to log multiple records and present a
	 * de-normalized view of it. To enable this behavior set this field to true.
	 * (defualt is false)
	 */
	protected boolean multipleRecords = false;

	// derived attributes
	protected String statement;

	protected List<Integer> parameterTypes;

	protected SqlUpdate slaRecordInsert;
	private boolean initialized = false;

	public JdbcSLALogger(DataSource datasource) {
		this.datasource = datasource;
	}

	@SuppressWarnings("unused")
	protected void init() {
		Assert
				.isTrue(
						(slaColumns != null || multipleRecords),
						"For non multiple record update, sla columns is mandatory. Sla columns should not be set "
								+ "if it is a multiplerecord update");
		parameterTypes = new ArrayList<Integer>();
		statement = "insert into " + tableName + " values (?"; // for request
																// Id.
		parameterTypes.add(Types.CHAR);
		if (multipleRecords) {
			addParamTypes();
		} else {
			for (String column : slaColumns) {
				addParamTypes();
			}
		}
		statement += ")";
		slaRecordInsert = new SqlUpdate(datasource, statement);
		for (int type : parameterTypes) {
			slaRecordInsert.declareParameter(new SqlParameter(type));
		}
		slaRecordInsert.compile();
		initialized = true;
	}

	protected void addParamTypes() {
		if (multipleRecords) {
			// store the record ID - different from request ID in this case
			// since there can be
			// multiple records for the same request
			statement += ",?";
			parameterTypes.add(Types.CHAR);
		}
		if (slaTypeStored) {
			statement += ",?";
			parameterTypes.add(Types.CHAR);
		}
		if (startTimeStored) {
			statement += ",?";
			parameterTypes.add(Types.TIMESTAMP);
		}
		if (endTimeStored) {
			statement += ",?";
			parameterTypes.add(Types.TIMESTAMP);
		}
		if (timeElapsedStored) {
			statement += ",?";
			parameterTypes.add(Types.BIGINT);
		}
	}

	@SuppressWarnings("unchecked")
	public void sla(final SLARecord slaRecord) {
		if (!initialized)
			init();
		logger.info("SLArecord is " + slaRecord);
		if (multipleRecords)
			updateMultiple(slaRecord);
		else
			updateSingle(slaRecord);
	}

	@SuppressWarnings("unchecked")
	protected void updateMultiple(SLARecord slaRecord) {
		for (SLATime slatime : slaRecord.getSlatimes().values()) {
			List stmtParams = new ArrayList();
			stmtParams.add(slaRecord.getRequestId());
			;
			populateStatementParams(stmtParams, slatime);
			slaRecordInsert.update(stmtParams.toArray());
		}
	}

	@SuppressWarnings("unchecked")
	protected void updateSingle(SLARecord slaRecord) {
		List stmtParams = new ArrayList();
		stmtParams.add(slaRecord.getRequestId());
		for (String column : slaColumns) {
			SLATime slatime = slaRecord.getSlaTime(column);
			populateStatementParams(stmtParams, slatime);
		}
		slaRecordInsert.update(stmtParams.toArray());
	}

	@SuppressWarnings("unchecked")
	protected void populateStatementParams(List stmtParams, SLATime slatime) {
		if (multipleRecords) {
			stmtParams.add(slatime.getSlatimeId());
		}
		if (startTimeStored) {
			// if(slatime == null) stmt.setNull(index++,Types.TIMESTAMP);
			// else
			stmtParams.add(new Timestamp(slatime.getStartTime()));
		}
		if (endTimeStored) {
			// if(slatime == null) stmt.setNull(index++,Types.TIMESTAMP);
			// else
			stmtParams.add(new Timestamp(slatime.getEndTime()));
		}
		if (timeElapsedStored) {
			// if(slatime == null) stmt.setNull(index++,Types.BIGINT);
			// else
			stmtParams.add(slatime.getTimeElapsed());
		}
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
		initialized = false;
	}

	public String[] getSlaColumns() {
		return slaColumns;
	}

	public void setSlaColumns(String[] slaColumns) {
		this.slaColumns = slaColumns;
		initialized = false;
	}

	public boolean isEndTimeStored() {
		return endTimeStored;
	}

	public void setEndTimeStored(boolean endTimeStored) {
		this.endTimeStored = endTimeStored;
		initialized = false;
	}

	public boolean isStartTimeStored() {
		return startTimeStored;
	}

	public void setStartTimeStored(boolean startTimeStored) {
		this.startTimeStored = startTimeStored;
		initialized = false;
	}

	public boolean isTimeElapsedStored() {
		return timeElapsedStored;
	}

	public void setTimeElapsedStored(boolean timeElapsedStored) {
		this.timeElapsedStored = timeElapsedStored;
		initialized = false;
	}

	public void setSlaTypeStored(boolean slaTypeStored) {
		this.slaTypeStored = slaTypeStored;
		initialized = false;
	}

	public void afterPropertiesSet() throws Exception {
		init();
	}

	public void setMultipleRecords(boolean multipleRecords) {
		this.multipleRecords = multipleRecords;
		initialized = false;
	}
}
